package com.atm;

public class Withdrawal extends Transaction {
	private int amount;

	//initialize constructor
	public Withdrawal(int accountNum, Bank bankData,int amount) {
		super(accountNum, bankData);
		this.amount=amount;
	}

	//check if withdrawal possible
	public boolean isWithdrawalPossible(){
		
		Account account = bankData.getAccount(accountNum);
		
		if(account.getCurrentBalance() < amount){
		return false;	
		}else{
			
			return true;
		}
		

	}
	@Override
	public void execute() {
		Account account = bankData.getAccount(accountNum);
		account.setCurrentBalance( account.getCurrentBalance()-amount);
		
	}

}
