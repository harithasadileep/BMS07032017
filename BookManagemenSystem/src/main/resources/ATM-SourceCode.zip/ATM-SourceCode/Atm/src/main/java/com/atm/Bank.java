package com.atm;

public class Bank {
	private Account[] accounts;

	// initialize constructor
	public Bank(Account accounts[]) {
		this.accounts=accounts;
	}

	// return the account for the corresponding account number
	public Account getAccount(int accountNum) {
		
		Account account =null;
		for (Account account1 : accounts) {
		
			if(account1.getAccountNum()==accountNum){
				account=account1;
			}
		}
		return account;

	}

	public boolean authenticateUser(int accn_no, int pin) {

		if ((accn_no == 101101234) && (pin == 1244)) {
			return true;
		} else if ((accn_no == 101101345) && (pin == 2325)) {
			return true;
		} else if ((accn_no == 10233243) && (pin == 5618)) {
			return true;
		} else {
			return false;
		}

	}
}
