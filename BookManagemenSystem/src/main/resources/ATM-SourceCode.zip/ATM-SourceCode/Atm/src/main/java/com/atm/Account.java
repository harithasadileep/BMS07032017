package com.atm;

public class Account {
	private int accountNum;
	private int pin;
	private int currentBalance;

	// initialize constructor
	public Account(int accountNum, int pin, int currentBalance) {
		this.accountNum = accountNum;
		this.pin = pin;
		this.currentBalance = currentBalance;

	}

	public int getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		this.currentBalance = currentBalance;
	}

}
