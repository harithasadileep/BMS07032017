/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code can not be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * Main application class for search.
 *
 * @author Chandra Gandu
 */
@EnableDiscoveryClient
@SpringBootApplication
public class SearchServiceApplication  {

    /**
     * Main method
     *
     * @param args
     *         Arguments to the program
     * @throws Exception
     *         Any exceptions encountered during startup
     */
    public static void main(final String[] args) throws Exception {
        new SpringApplication(SearchServiceApplication.class).run(args);
    }
    

}