/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code can not be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx.search.controller;

import com.google.common.base.Ticker;
import com.innominds.myspacenx.search.dto.Filter;
import com.innominds.myspacenx.search.dto.SearchProspectResult;
import com.innominds.myspacenx.search.persistence.IndexableDocument;
import com.innominds.myspacenx.search.service.SearchService;

import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.List;

/**
 * APIs for search functionality.
 *
 * @author Chandra Gandu
 */
@RestController
public class SearchApiController {

    /** Search service */
    private SearchService searchService;

    @Autowired
    public SearchApiController(final SearchService searchService) {
        this.searchService = searchService;
    }

    /**
     * Search prospects.
     *
     * @param body
     *         the body
     * @param pageNumber
     *         the page number
     * @param pageSize
     *         the page size
     * @return the response entity
     */
    @GetMapping("/search/documents")
    public ResponseEntity<List<SearchProspectResult>> searchProspects(@RequestBody final List<Filter> body, final Integer pageNumber, final Integer pageSize) {
        // do some magic!
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * indexing document in elastic search.
     *
     * @param document
     * @return
     * @throws Exception
     */
    @PostMapping("/documents")
    public ResponseEntity<Void> indexDocument(@RequestBody IndexableDocument document) throws Exception {
        searchService.indexDocument(document);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Method to get prospect details by name.
     *
     * @param prospectName
     * @return
     * @throws IOException
     * @throws TikaException
     * @throws SAXException
     */
    @RequestMapping(path = "/search/{name}", method = RequestMethod.GET)
    public ResponseEntity<List<IndexableDocument>> getProspectByName(@PathVariable("name") String prospectName) throws IOException, TikaException, SAXException {

        final List<IndexableDocument> prospectList = searchService.getDocumentsBelongingTo(prospectName);
        return new ResponseEntity<>(prospectList, HttpStatus.OK);
    }

}
