/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code can not be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx.search.service;

import com.innominds.myspacenx.search.persistence.IndexableDocument;
import com.innominds.myspacenx.search.repository.SearchRepository;
import com.innominds.myspacenx.search.util.TikaUtil;

import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 * Service implementation for search.
 *
 * @author Chandra Gandu
 */
@Service
public class SearchService {

    /** Search repository */
    private SearchRepository searchRepository;

    /** Reference to the elasticsearch template */
    private ElasticsearchTemplate template;

    @Autowired
    public SearchService(final SearchRepository searchRepository, final ElasticsearchTemplate template) {
        this.searchRepository = searchRepository;
        this.template = template;
    }

    /**
     * Method that is responsible to index the provided document
     *
     * @param document
     *         Document object that needs to be indexed
     * @throws Exception
     */
    public void indexDocument(IndexableDocument document) throws Exception {
        try {
        	File file = transferTo(document.getUploadedFile());
//        	saveFile(file);
            String parsedText = TikaUtil.parse(file);
            document.setFileContent(parsedText);
            template.putMapping(IndexableDocument.class);
            searchRepository.save(document);
        } catch (IllegalStateException | IOException | TikaException | SAXException ex) {
            throw ex;
        }
    }

    /**
     * Saves the given document in local directory
     * @param file
     */
    private void saveFile(File file) {
    	FileOutputStream out = null;
		try {
			out = new FileOutputStream(file.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
     * This method returns the documents that are associated to a specific prospect / user identified by the provided name.
     *
     * @param name
     *         Name of the user whose documents have to be retrieved
     * @return Collection of document objects belong to the specific user. Every element in the collection is an object of type {@link IndexableDocument}
     */
    public List<IndexableDocument> getDocumentsBelongingTo(final String name) {
        // return searchRepository.findProspectByName(name);
        return null;
    }

    /**
     * Method that is responsible to transfer the provided multi-part file object (of type {@link MultipartFile}) to the destination location.
     *
     * @param multipart
     *         Multipart file that needs to be transferred to the destination location
     * @return Destination file
     * @throws IllegalStateException
     * @throws IOException
     */
    private File transferTo(final MultipartFile multipart) throws IllegalStateException, IOException {
        // Is the below statement correct???? Need to confirm
        final File file = new File(multipart.getOriginalFilename());
        multipart.transferTo(file);
        return file;
    }

}
