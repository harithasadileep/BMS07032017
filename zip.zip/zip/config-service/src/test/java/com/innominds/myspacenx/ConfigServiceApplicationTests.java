/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code cannot be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * The Class ConfigServiceApplicationTests.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ConfigServiceApplicationTests {

    /**
     * Context loads.
     */
    @Test
    public void contextLoads() {
        /*
         * Implement when required
		 */
    }

}
