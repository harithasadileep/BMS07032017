/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code cannot be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * Main class for the Config Service.
 *
 * @author Chandra Veerapaneni
 */
@SpringBootApplication
@EnableConfigServer
public class ConfigServiceApplication {

    /**
     * Entry point method.
     *
     * @param args
     *         Arguments to the program.
     */
    public static void main(final String[] args) {
        SpringApplication.run(ConfigServiceApplication.class, args);
    }
}
