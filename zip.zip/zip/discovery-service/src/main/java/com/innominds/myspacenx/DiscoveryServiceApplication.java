/******************************************************************************
 * Copyright (C) 1998-2017 Application Development, Innominds Software Pvt Ltd.
 *
 * This file is part of MySpaceNX Project
 *
 * MySpaceNX Project and associated code can not be copied and/or distributed
 * without a written permission of Innominds Software Pvt Ltd., and/or it
 * subsidiaries
 *
 *****************************************************************************/
package com.innominds.myspacenx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Main class for the Eureka discovery service
 *
 * @author Chandra Veerapaneni
 */
@EnableEurekaServer
@EnableDiscoveryClient
@SpringBootApplication
public class DiscoveryServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiscoveryServiceApplication.class, args);
    }
}
